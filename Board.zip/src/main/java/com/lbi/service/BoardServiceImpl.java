package com.lbi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lbi.mapper.BoardMapper;
import com.lbi.model.BoardVO;
import com.lbi.model.Criteria;

@Service
public class BoardServiceImpl implements BoardService{

	@Autowired
	private BoardMapper mapper;
	
	@Override
	public void enroll(BoardVO board) {
		mapper.enroll(board);
	}

	@Override
	public List<BoardVO> getList() {
		return mapper.getList();
	}

	@Override
	public BoardVO getPage(int bno) {
		return mapper.getPage(bno);
	}

	 /* �Խ��� ���� */
    @Override
    public int modify(BoardVO board) {
        return mapper.modify(board);
    }

    /*�Խ��� ����*/
	@Override
	public int delete(int bno) {
		return mapper.delete(bno);
	}

	/*�Խ��� ���(����¡ ����)*/
	@Override
	public List<BoardVO> getListPaging(Criteria cri) {
		return mapper.getListPaging(cri);
	}

	
	/*�Խ��� �� ����*/
	@Override
	public int getTotal() {
		return mapper.getTotal();
		
	}
	

}
